import msprime, tskit, pyslim

ts = tskit.load("overlay.trees").simplify()
ts = pyslim.convert_alleles(pyslim.generate_nucleotides(ts))
mutated = msprime.sim_mutations(ts, rate=1e-7, random_seed=1, keep=True)
mutated.dump("final_overlaid.trees")
